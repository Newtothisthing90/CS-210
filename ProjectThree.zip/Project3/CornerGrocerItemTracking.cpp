//Lawrence Langelier
//2/23/25

#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <limits>
using namespace std;

class ItemTracker {
private:
    map<string, int> itemFrequency;

    // Writes backup data to "frequency.dat"
    void writeBackupData() {
        ofstream outFile("frequency.dat");
        if (outFile.is_open()) {
            for (auto entry : itemFrequency)
                outFile << entry.first << " " << entry.second << "\n";
            outFile.close();
        }
        else {
            cout << "Error: Cannot create backup file!" << endl;
        }
    }

public:
    // Load data from the provided file path
    bool loadData(const string& filename) {
        ifstream inFile(filename);
        if (!inFile.is_open()) {
            cout << "Error: Cannot open file " << filename << endl;
            return false;
        }

        string item;
        while (inFile >> item)
            itemFrequency[item]++;
        inFile.close();

        writeBackupData();
        return true;
    }

    int getFrequency(const string& item) {
        return itemFrequency[item];
    }

    void displayAll() {
        for (auto entry : itemFrequency)
            cout << entry.first << ": " << entry.second << "\n";
    }

    void displayHistogram() {
        for (auto entry : itemFrequency) {
            cout << entry.first << " ";
            for (int i = 0; i < entry.second; i++)
                cout << "*";
            cout << "\n";
        }
    }
};

void displayMenu() {
    cout << "\nMenu Options:\n";
    cout << "1. Search for an item's frequency\n";
    cout << "2. Display frequency for all items\n";
    cout << "3. Display histogram of item frequencies\n";
    cout << "4. Exit\n";
    cout << "Enter your choice: ";
}

int main() {
    ItemTracker tracker;

    // Ask user to enter the file path manually
    string filename;
    cout << "Enter the full path to your text file: ";
    getline(cin, filename);  // Allows spaces in the file path

    if (!tracker.loadData(filename))
        return 1;  // Exit if file loading fails

    int choice;
    do {
        displayMenu();
        cin >> choice;

        if (cin.fail()) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Invalid input. Please enter a number between 1 and 4." << endl;
            continue;
        }

        if (choice == 1) {
            cout << "Enter item to search: ";
            string item;
            cin >> item;
            cout << item << ": " << tracker.getFrequency(item) << "\n";
        }
        else if (choice == 2) {
            tracker.displayAll();
        }
        else if (choice == 3) {
            tracker.displayHistogram();
        }
        else if (choice == 4) {
            cout << "Exiting program.\n";
        }
        else {
            cout << "Invalid choice, try again.\n";
        }
    } while (choice != 4);

    return 0;
}
